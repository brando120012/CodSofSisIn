archivo="Alumno.txt"
with open(archivo,"r") as fichero:
    for linea in fichero.readlines():
        print(linea, end="") str
